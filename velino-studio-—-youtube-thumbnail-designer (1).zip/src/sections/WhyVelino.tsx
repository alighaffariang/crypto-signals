import React from "react";
import { whyVelinoItems } from "../data/siteConfig";

export const WhyVelino: React.FC = () => {
  return (
    <section
      aria-labelledby="why-velino-heading"
      className="velino-section-divider relative w-full bg-transparent py-12 sm:py-20 md:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        {/* Centered Section Header */}
        <div className="max-w-4xl mx-auto text-center">
          <span className="font-mono text-xs sm:text-sm font-bold uppercase tracking-widest text-[#B6FF00]">
            AGENCY ADVANTAGE
          </span>
          <h2
            id="why-velino-heading"
            className="mt-2 font-display text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-tight"
          >
            WHY WORK WITH{" "}
            <span className="velino-luminous-title text-[#B6FF00]">VELINO?</span>
          </h2>
          <p className="mt-3.5 sm:mt-5 max-w-2xl mx-auto font-display text-base sm:text-xl md:text-2xl font-bold uppercase tracking-tight text-white/95">
            We make video editing easier, so you can focus on creating content.
          </p>
        </div>

        {/* 4 Benefits Cards Grid */}
        <div className="mt-8 sm:mt-14 md:mt-18 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 items-stretch">
          {whyVelinoItems.map((item) => (
            <div
              key={item.id}
              className="velino-glass-card flex flex-col justify-between p-5 sm:p-7 md:p-8 border border-white/15 transition-all duration-150 hover:border-[#B6FF00]/60"
            >
              <div>
                <div className="flex items-center justify-between border-b border-white/10 pb-3 sm:pb-4">
                  <span className="font-mono text-base sm:text-xl font-bold text-[#B6FF00] tabular-nums">
                    {item.index}
                  </span>
                  <span
                    aria-hidden="true"
                    className="h-1.5 w-1.5 md:h-2 md:w-2 bg-[#B6FF00] shadow-[0_0_10px_#B6FF00]"
                  />
                </div>

                <h3 className="mt-4 sm:mt-5 font-display text-base sm:text-lg md:text-xl font-black uppercase tracking-tight text-white leading-snug">
                  {item.title}
                </h3>

                <p className="mt-2.5 sm:mt-3 text-xs sm:text-sm leading-relaxed text-neutral-300">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
