import React from "react";
import {
  row1Testimonials,
  row2Testimonials,
  row3Testimonials,
  TestimonialEntry,
} from "../data/testimonialsData";

const TestimonialCard: React.FC<{ item: TestimonialEntry }> = ({ item }) => {
  return (
    <article className="velino-testimonial-card rounded-xl flex w-[280px] sm:w-[340px] md:w-[390px] shrink-0 flex-col justify-between p-4 sm:p-5 md:p-6 select-none border border-white/12">
      {/* Testimonial Review Text as the Primary Focus */}
      <blockquote className="mb-4">
        <p className="text-xs sm:text-[13px] md:text-[14px] leading-relaxed text-neutral-200">
          "{item.review}"
        </p>
      </blockquote>

      {/* Reviewer Details: Name with Country and National Flag Beneath */}
      <footer className="border-t border-white/10 pt-3 flex flex-col">
        <span className="font-display text-xs sm:text-sm font-bold tracking-tight text-white">
          {item.name}
        </span>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span
            aria-hidden="true"
            className="text-xs sm:text-sm shrink-0 leading-none select-none"
          >
            {item.flag}
          </span>
          <span className="font-mono text-[10px] sm:text-[11px] text-[#B6FF00]/90 uppercase tracking-wider">
            {item.country}
          </span>
        </div>
      </footer>
    </article>
  );
};

export const Testimonials: React.FC = () => {
  return (
    <section
      id="testimonials"
      aria-label="Client feedback"
      className="velino-section-divider relative w-full overflow-hidden bg-transparent py-8 sm:py-12 md:py-16"
    >
      {/* Background Ambient Glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[420px] w-[720px] bg-[radial-gradient(ellipse_at_center,rgba(182,255,0,0.1)_0%,rgba(147,51,234,0.03)_45%,transparent_76%)] blur-3xl" />
      </div>

      {/* 3-Row Infinite Marquee Wall */}
      <div className="relative z-10 flex flex-col gap-3 sm:gap-4 overflow-hidden">
        {/* Soft edge fade masks */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 left-0 z-20 w-8 sm:w-20 md:w-32 bg-gradient-to-r from-[#050605] via-[#050605]/70 to-transparent"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 right-0 z-20 w-8 sm:w-20 md:w-32 bg-gradient-to-l from-[#050605] via-[#050605]/70 to-transparent"
        />

        {/* Row 1: Left to Right */}
        <div className="testimonial-row-container relative w-full overflow-hidden">
          <div className="animate-testimonial-row-1">
            <div className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4">
              {row1Testimonials.map((item) => (
                <TestimonialCard key={`row1-a-${item.id}`} item={item} />
              ))}
            </div>
            <div
              className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4"
              aria-hidden="true"
            >
              {row1Testimonials.map((item) => (
                <TestimonialCard key={`row1-b-${item.id}`} item={item} />
              ))}
            </div>
          </div>
        </div>

        {/* Row 2: Right to Left */}
        <div className="testimonial-row-container relative w-full overflow-hidden">
          <div className="animate-testimonial-row-2">
            <div className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4">
              {row2Testimonials.map((item) => (
                <TestimonialCard key={`row2-a-${item.id}`} item={item} />
              ))}
            </div>
            <div
              className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4"
              aria-hidden="true"
            >
              {row2Testimonials.map((item) => (
                <TestimonialCard key={`row2-b-${item.id}`} item={item} />
              ))}
            </div>
          </div>
        </div>

        {/* Row 3: Left to Right */}
        <div className="testimonial-row-container relative w-full overflow-hidden">
          <div className="animate-testimonial-row-3">
            <div className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4">
              {row3Testimonials.map((item) => (
                <TestimonialCard key={`row3-a-${item.id}`} item={item} />
              ))}
            </div>
            <div
              className="flex shrink-0 items-stretch gap-3 sm:gap-4 pr-3 sm:pr-4"
              aria-hidden="true"
            >
              {row3Testimonials.map((item) => (
                <TestimonialCard key={`row3-b-${item.id}`} item={item} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
