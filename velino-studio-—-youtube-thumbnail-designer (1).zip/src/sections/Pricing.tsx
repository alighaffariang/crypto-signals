import React, { useState } from "react";
import { ArrowRight, Check, Clock, Sparkles } from "lucide-react";
import { createInquiryMailto } from "../data/siteConfig";

interface PricingProps {
  onSelectPackage?: (
    packageName: string,
    serviceType?: string,
    duration?: string
  ) => void;
}

type LongFormDuration = "1-3" | "3-5" | "5-10" | "over-10";

interface DurationOption {
  id: LongFormDuration;
  label: string;
  priceDisplay: string;
  isCustom: boolean;
}

const durationOptions: DurationOption[] = [
  {
    id: "1-3",
    label: "1–3 MINUTES",
    priceDisplay: "$100",
    isCustom: false,
  },
  {
    id: "3-5",
    label: "3–5 MINUTES",
    priceDisplay: "$150",
    isCustom: false,
  },
  {
    id: "5-10",
    label: "5–10 MINUTES",
    priceDisplay: "$200",
    isCustom: false,
  },
  {
    id: "over-10",
    label: "OVER 10 MINUTES",
    priceDisplay: "CUSTOM QUOTE",
    isCustom: true,
  },
];

const shortFormFeatures = [
  "Engaging cuts and pacing",
  "Music and sound effects",
  "Subtitles when needed",
  "Professional transitions and visual enhancements",
  "Unlimited revisions until you're completely satisfied",
  "24-hour delivery",
];

const longFormFeatures = [
  "Structured cuts and pacing",
  "Audio cleanup and balancing",
  "Music and sound effects",
  "Supporting visuals & visual enhancements",
  "High-quality final export",
  "Unlimited revisions until you're completely satisfied",
  "24-hour delivery",
];

export const Pricing: React.FC<PricingProps> = ({ onSelectPackage }) => {
  // Initially select the 1–3 minutes option and display $100
  const [selectedDurationId, setSelectedDurationId] =
    useState<LongFormDuration>("1-3");

  const currentDuration =
    durationOptions.find((opt) => opt.id === selectedDurationId) ||
    durationOptions[0];

  const handleShortFormOrder = () => {
    if (onSelectPackage) {
      onSelectPackage(
        "Short-Form Video Editing ($50 / video)",
        "Short-Form Video Editing",
        "Under 60 seconds"
      );
    }
    const mailto = createInquiryMailto({
      service: "Short-Form Video Editing",
      price: "$50 / video",
    });
    window.location.href = mailto;
  };

  const handleLongFormOrder = () => {
    const displayedPrice = currentDuration.isCustom
      ? "Custom Quote"
      : `${currentDuration.priceDisplay} / video`;

    if (onSelectPackage) {
      onSelectPackage(
        `Long-Form Video Editing: ${currentDuration.label} (${displayedPrice})`,
        currentDuration.isCustom
          ? "Custom Project / Recurring"
          : "Long-Form Video Editing",
        currentDuration.label
      );
    }
    const mailto = createInquiryMailto({
      service: "Long-Form Video Editing",
      duration: currentDuration.label,
      price: displayedPrice,
    });
    window.location.href = mailto;
  };

  return (
    <section
      id="pricing"
      aria-labelledby="pricing-heading"
      className="velino-section-divider relative w-full bg-transparent py-12 sm:py-20 md:py-28 lg:py-36"
    >
      {/* Background Ambient Glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute top-1/4 right-[5%] h-[460px] w-[680px] bg-[radial-gradient(ellipse_at_center,rgba(182,255,0,0.12)_0%,rgba(147,51,234,0.035)_45%,transparent_76%)] blur-3xl" />
        <div className="absolute bottom-10 left-[8%] h-[380px] w-[560px] bg-[radial-gradient(ellipse_at_center,rgba(56,189,248,0.04)_0%,transparent_75%)] blur-2xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-10 sm:mb-16">
          <h2
            id="pricing-heading"
            className="font-display text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-tight"
          >
            SIMPLE.{" "}
            <span className="velino-luminous-title text-[#B6FF00]">
              TRANSPARENT PRICING.
            </span>
          </h2>
          <p className="mt-3.5 sm:mt-4 text-[14px] sm:text-base md:text-lg text-neutral-300">
            Professional video editing, transparent pricing, and 24-hour delivery.
          </p>
        </div>

        {/* 2-Card Layout: Short-Form (Single Card) & Long-Form (ONE Interactive Card) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 max-w-[1120px] mx-auto items-stretch">
          {/* ========================================================= */}
          {/* 1. SHORT-FORM VIDEO EDITING (SINGLE SEPARATE PRICING CARD) */}
          {/* ========================================================= */}
          <div className="velino-glass-card relative flex flex-col justify-between p-6 sm:p-8 md:p-10 border border-white/15 hover:border-[#B6FF00]/50 transition-all duration-200">
            <div>
              {/* Header */}
              <div className="border-b border-white/10 pb-4 sm:pb-5">
                <h3 className="font-display text-xl sm:text-2xl md:text-3xl font-black uppercase tracking-tight text-white">
                  SHORT-FORM VIDEO EDITING
                </h3>
              </div>

              {/* Description */}
              <p className="mt-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                Professional editing for YouTube Shorts, Instagram Reels, and more.
              </p>

              {/* Price: The Visual Focus */}
              <div className="mt-6 p-5 border border-white/10 bg-[#060806]/90">
                <div className="flex items-baseline gap-2 min-h-[58px] sm:min-h-[72px] items-center">
                  <span className="velino-luminous-title font-display text-5xl sm:text-6xl md:text-7xl font-black tracking-tight text-[#B6FF00] tabular-nums">
                    $50
                  </span>
                  <span className="font-mono text-sm sm:text-base font-bold text-neutral-300 uppercase">
                    / VIDEO
                  </span>
                </div>
              </div>

              {/* Features List */}
              <div className="mt-6 space-y-3">
                <p className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 font-semibold">
                  FEATURES INCLUDED:
                </p>
                {shortFormFeatures.map((feature) => (
                  <div
                    key={feature}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-200"
                  >
                    <Check className="h-4 w-4 text-[#B6FF00] shrink-0 mt-0.5" />
                    <span className={feature.includes("Unlimited") || feature.includes("24-hour") ? "text-[#B6FF00] font-semibold" : ""}>
                      {feature}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button */}
            <div className="mt-8 pt-4">
              <button
                type="button"
                onClick={handleShortFormOrder}
                className="velino-neon-btn inline-flex w-full items-center justify-center gap-2 bg-[#B6FF00] py-3.5 px-6 text-xs sm:text-sm font-extrabold uppercase tracking-wider text-black transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#c8ff3d] cursor-pointer"
              >
                <span>GET STARTED</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 2. LONG-FORM VIDEO EDITING (ONE INTERACTIVE PRICING CARD) */}
          {/* ========================================================= */}
          <div className="velino-featured-surface relative flex flex-col justify-between p-6 sm:p-8 md:p-10 border-2 border-[#B6FF00] shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_36px_rgba(182,255,0,0.15)] transition-all duration-200">
            <div>
              {/* Header */}
              <div className="border-b border-white/10 pb-4 sm:pb-5">
                <h3 className="font-display text-xl sm:text-2xl md:text-3xl font-black uppercase tracking-tight text-white">
                  LONG-FORM VIDEO EDITING
                </h3>
              </div>

              {/* Description */}
              <p className="mt-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                Choose your preferred video length to see the price.
              </p>

              {/* Dynamic Price: The Visual Focus of the Card */}
              <div className="mt-6 p-5 border border-white/15 bg-[#060806]/95">
                <div className="flex items-center justify-between min-h-[58px] sm:min-h-[72px]">
                  {currentDuration.isCustom ? (
                    <div className="flex items-baseline gap-2">
                      <span className="velino-luminous-title font-display text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-[#B6FF00] uppercase">
                        CUSTOM QUOTE
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-baseline gap-2">
                      <span className="velino-luminous-title font-display text-5xl sm:text-6xl md:text-7xl font-black tracking-tight text-[#B6FF00] tabular-nums">
                        {currentDuration.priceDisplay}
                      </span>
                      <span className="font-mono text-sm sm:text-base font-bold text-neutral-300 uppercase">
                        / VIDEO
                      </span>
                    </div>
                  )}

                  <span className="font-mono text-[10px] font-bold text-[#B6FF00] bg-[#B6FF00]/10 px-2.5 py-1 border border-[#B6FF00]/30 shrink-0">
                    {currentDuration.label}
                  </span>
                </div>
              </div>

              {/* Interactive Duration Selector with 4 Clickable Options (NO prices inside buttons) */}
              <div className="mt-6">
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-300 font-bold flex items-center gap-1.5">
                    <Clock className="h-3 w-3 text-[#B6FF00]" />
                    SELECT VIDEO LENGTH:
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
                  {durationOptions.map((opt) => {
                    const isSelected = opt.id === selectedDurationId;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSelectedDurationId(opt.id)}
                        aria-pressed={isSelected}
                        className={`flex items-center justify-center p-3 sm:p-3.5 border text-center transition-all duration-150 cursor-pointer ${
                          isSelected
                            ? "bg-[#B6FF00] text-black border-[#B6FF00] font-black shadow-[0_0_16px_rgba(182,255,0,0.4)] ring-1 ring-[#B6FF00]"
                            : "bg-[#060806]/80 text-neutral-300 border-white/15 hover:border-[#B6FF00]/60 hover:text-white font-bold"
                        }`}
                      >
                        <span className="font-display text-xs sm:text-sm font-black tracking-wide uppercase">
                          {opt.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Features List */}
              <div className="mt-6 space-y-3">
                <p className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 font-semibold">
                  FEATURES INCLUDED:
                </p>
                {longFormFeatures.map((feature) => (
                  <div
                    key={feature}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-200"
                  >
                    <Check className="h-4 w-4 text-[#B6FF00] shrink-0 mt-0.5" />
                    <span className={feature.includes("Unlimited") || feature.includes("24-hour") ? "text-[#B6FF00] font-semibold" : ""}>
                      {feature}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button: Updates dynamically between GET STARTED and REQUEST A QUOTE */}
            <div className="mt-8 pt-4">
              <button
                type="button"
                onClick={handleLongFormOrder}
                className="velino-neon-btn inline-flex w-full items-center justify-center gap-2 bg-[#B6FF00] py-3.5 px-6 text-xs sm:text-sm font-extrabold uppercase tracking-wider text-black transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#c8ff3d] cursor-pointer"
              >
                <span>
                  {currentDuration.isCustom ? "REQUEST A QUOTE" : "GET STARTED"}
                </span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Unlimited Revisions Assurance below pricing cards */}
        <div className="mt-8 sm:mt-12 flex items-center justify-center">
          <span className="inline-flex items-center gap-2 border border-[#B6FF00]/30 bg-[#B6FF00]/10 px-4 py-2 text-xs sm:text-sm font-mono font-bold uppercase tracking-wider text-[#B6FF00] shadow-[0_0_20px_rgba(182,255,0,0.12)]">
            <Sparkles className="h-3.5 w-3.5" />
            We’ll keep refining your video until you’re completely satisfied.
          </span>
        </div>
      </div>
    </section>
  );
};
