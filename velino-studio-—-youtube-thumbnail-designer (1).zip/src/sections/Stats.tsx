import React, { useEffect, useRef, useState } from "react";
import { agencyStatistics, AgencyStat } from "../data/statsData";

// Slower, smooth count-up duration targeting ~4.0 seconds (within 3.5–4.5s requirement)
const ANIMATION_DURATION_MS = 4000;

export const Stats: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const hasAnimatedRef = useRef(false);

  // Initial display values: zero before animation starts
  const [counts, setCounts] = useState<{ [key: string]: number }>({
    "edited-projects": 0,
    clients: 0,
    views: 0,
  });

  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    let rafId: number | null = null;

    const startCounting = () => {
      if (hasAnimatedRef.current) return;
      hasAnimatedRef.current = true;

      // Accessibility: Respect reduced motion preferences
      if (
        typeof window !== "undefined" &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ) {
        const finalCounts: { [key: string]: number } = {};
        agencyStatistics.forEach((stat) => {
          finalCounts[stat.id] = stat.targetValue;
        });
        setCounts(finalCounts);
        setIsCompleted(true);
        return;
      }

      const startTime = performance.now();

      const tick = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / ANIMATION_DURATION_MS, 1);
        // Smooth cubic ease-out for calm, steady, natural deceleration without unnatural jumps
        const eased = 1 - Math.pow(1 - progress, 3);

        const currentCounts: { [key: string]: number } = {};
        agencyStatistics.forEach((stat) => {
          currentCounts[stat.id] = Math.round(stat.targetValue * eased);
        });

        setCounts(currentCounts);

        if (progress < 1) {
          rafId = window.requestAnimationFrame(tick);
        } else {
          const finalCounts: { [key: string]: number } = {};
          agencyStatistics.forEach((stat) => {
            finalCounts[stat.id] = stat.targetValue;
          });
          setCounts(finalCounts);
          setIsCompleted(true);
        }
      };

      rafId = window.requestAnimationFrame(tick);
    };

    // Trigger when section enters viewport; disconnect immediately so it does not restart during minor scrolling
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry && entry.isIntersecting) {
          startCounting();
          observer.disconnect();
        }
      },
      { threshold: 0.25 }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
      }
    };
  }, []);

  return (
    <section
      aria-label="Agency Track Record"
      className="velino-section-divider relative w-full bg-transparent py-10 sm:py-14 md:py-18"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div
          ref={containerRef}
          className="mx-auto w-full max-w-4xl grid grid-cols-3 divide-x divide-white/15 border border-white/12 bg-[#070907]/70 py-7 sm:py-10 md:py-12 backdrop-blur-md shadow-[0_12px_40px_rgba(0,0,0,0.85)]"
        >
          {agencyStatistics.map((stat) => (
            <div
              key={stat.id}
              className="flex flex-col items-center justify-center px-2 sm:px-6 md:px-8 text-center"
            >
              {/* Main Metric Display: Suffix like 'M' inherits same color as the digits */}
              <div className="font-display text-2xl sm:text-4xl md:text-6xl font-black tracking-tight text-white leading-none tabular-nums [text-shadow:0_0_24px_rgba(182,255,0,0.22)]">
                {stat.prefix && (
                  <span className="text-[#B6FF00] drop-shadow-[0_0_12px_rgba(182,255,0,0.45)]">
                    {stat.prefix}
                  </span>
                )}
                <span>
                  {stat.formatCommas
                    ? (counts[stat.id] || 0).toLocaleString("en-US")
                    : counts[stat.id] || 0}
                </span>
                {/* Suffix inherits text-white so 989M has identical color across all 4 characters */}
                {stat.suffix && <span>{stat.suffix}</span>}
              </div>

              <p className="mt-2 sm:mt-3 font-mono text-[10px] sm:text-xs md:text-sm font-bold uppercase tracking-wider text-neutral-300">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
