import React from "react";
import { valueProposition } from "../data/siteConfig";

export const AttentionStatement: React.FC = () => {
  return (
    <section
      aria-label="Value Proposition"
      className="velino-section-divider relative w-full bg-transparent py-12 sm:py-20 md:py-28 lg:py-36"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-2xl sm:text-4xl md:text-6xl lg:text-7xl font-black uppercase tracking-[-0.03em] text-white leading-[1.04] md:leading-[1.02] [text-wrap:balance] mx-auto">
            {valueProposition.headline}
          </h2>

          <p className="mt-4 sm:mt-6 md:mt-8 max-w-3xl mx-auto text-[14px] sm:text-lg md:text-2xl font-medium leading-relaxed text-neutral-300">
            {valueProposition.supportingText}
          </p>

          <div className="mt-8 sm:mt-12 md:mt-16 text-center">
            <p className="font-display text-xl sm:text-3xl md:text-5xl lg:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-tight">
              {valueProposition.closingStatementLine1}
            </p>
            <p className="velino-luminous-title font-display text-2xl sm:text-4xl md:text-7xl lg:text-8xl font-black uppercase tracking-[-0.04em] text-[#B6FF00] leading-none mt-2 sm:mt-3">
              {valueProposition.closingStatementLine2}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
