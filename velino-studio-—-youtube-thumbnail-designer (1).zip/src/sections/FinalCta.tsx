import React from "react";
import { ArrowRight } from "lucide-react";
import { finalCtaContent, createGeneralInquiryMailto } from "../data/siteConfig";

interface FinalCtaProps {
  onNavigate?: (sectionId: string) => void;
}

export const FinalCta: React.FC<FinalCtaProps> = () => {
  const handleEmailOrder = () => {
    window.location.href = createGeneralInquiryMailto("Final CTA");
  };

  return (
    <section
      aria-label="Final Call to Action"
      className="velino-section-divider relative w-full overflow-hidden bg-transparent py-14 sm:py-20 md:py-28"
    >
      {/* Glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_55%_55%_at_50%_50%,rgba(182,255,0,0.14)_0%,rgba(147,51,234,0.045)_45%,transparent_76%)]"
      />

      <div className="relative z-10 mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="mx-auto max-w-4xl font-display text-2xl sm:text-4xl md:text-7xl font-black uppercase tracking-[-0.03em] text-white leading-[1.02] sm:leading-[0.98] [text-wrap:balance]">
          READY TO LEVEL UP{" "}
          <span className="velino-luminous-title text-[#B6FF00]">
            YOUR CONTENT?
          </span>
        </h2>

        <div className="mt-8 sm:mt-10 md:mt-12 flex justify-center">
          <button
            type="button"
            onClick={handleEmailOrder}
            className="velino-neon-btn inline-flex items-center justify-center gap-2 bg-[#B6FF00] px-7 py-3 sm:px-10 sm:py-4.5 text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider text-black transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#c8ff3d] active:translate-y-0 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B6FF00]"
          >
            <span>{finalCtaContent.primaryCta}</span>
            <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5" />
          </button>
        </div>
      </div>
    </section>
  );
};
