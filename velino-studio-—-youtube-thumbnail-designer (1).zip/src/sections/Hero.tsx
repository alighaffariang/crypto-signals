import React from "react";
import { ArrowRight } from "lucide-react";
import { heroContent, createGeneralInquiryMailto } from "../data/siteConfig";

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  const handleEmailOrder = () => {
    window.location.href = createGeneralInquiryMailto("Hero CTA");
  };

  return (
    <section
      id="top"
      aria-labelledby="hero-heading"
      className="velino-section-divider relative w-full overflow-hidden bg-transparent pt-10 pb-12 sm:pt-16 sm:pb-20 md:pt-24 md:pb-28 lg:pt-28 lg:pb-32"
    >
      {/* Subtle Ambient Lighting Accents */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 h-[420px] w-[680px] sm:h-[580px] sm:w-[960px] bg-[radial-gradient(ellipse_at_center,rgba(182,255,0,0.22)_0%,rgba(182,255,0,0.08)_44%,transparent_76%)] blur-2xl" />
        <div className="absolute top-12 left-1/2 -translate-x-1/2 h-[240px] w-[480px] bg-[radial-gradient(ellipse_at_center,rgba(238,255,250,0.1)_0%,rgba(186,230,253,0.03)_48%,transparent_75%)] blur-xl" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[260px] w-[540px] bg-[radial-gradient(ellipse_at_center,rgba(147,51,234,0.065)_0%,rgba(124,58,237,0.02)_50%,transparent_78%)] blur-2xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center flex flex-col items-center">

          {/* Primary Headline */}
          <h1
            id="hero-heading"
            className="font-display text-3xl sm:text-5xl md:text-7xl lg:text-[5.25rem] font-black uppercase tracking-[-0.03em] text-white leading-[1.02] sm:leading-[0.98] [text-wrap:balance]"
          >
            {heroContent.headlineLine1}
            <br />
            <span className="velino-luminous-title text-[#B6FF00]">
              {heroContent.headlineLine2}
            </span>
            <br />
            {heroContent.headlineLine3}
          </h1>

          {/* Supporting Headline */}
          <p className="mt-3.5 sm:mt-6 md:mt-8 max-w-3xl mx-auto font-display text-base sm:text-xl md:text-3xl font-bold uppercase tracking-tight text-white/95 [text-wrap:balance]">
            {heroContent.supportingHeadline}
          </p>

          {/* Description */}
          <p className="mt-3 sm:mt-4 md:mt-5 max-w-2xl mx-auto text-[13px] sm:text-base md:text-xl leading-relaxed text-neutral-300">
            {heroContent.description}
          </p>

          {/* Centered CTAs */}
          <div className="mt-6 sm:mt-8 md:mt-11 flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 sm:gap-4 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleEmailOrder}
              className="velino-neon-btn inline-flex items-center justify-center gap-2 bg-[#B6FF00] px-6 py-3 sm:px-8 sm:py-4 text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider text-black transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#c8ff3d] active:translate-y-0 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B6FF00]"
            >
              <span>{heroContent.primaryCta}</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate("pricing")}
              className="inline-flex items-center justify-center gap-2 border border-white/20 bg-white/5 px-6 py-3 sm:px-7 sm:py-4 text-xs sm:text-sm md:text-base font-bold uppercase tracking-wider text-neutral-200 transition-colors duration-150 hover:border-[#B6FF00] hover:text-[#B6FF00] hover:bg-white/10 active:translate-y-0 whitespace-nowrap cursor-pointer"
            >
              <span>VIEW PRICING</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
