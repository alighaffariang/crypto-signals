import React, { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { faqItems } from "../data/siteConfig";

export const FAQ: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>("faq-01");

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="velino-section-divider relative w-full bg-transparent py-12 sm:py-20 md:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        {/* Centered Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-8 sm:mb-12">
          <h2
            id="faq-heading"
            className="font-display text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-[1.02] [text-wrap:balance]"
          >
            FREQUENTLY ASKED{" "}
            <span className="velino-luminous-title text-[#B6FF00]">
              QUESTIONS.
            </span>
          </h2>
        </div>

        {/* Centered Accordion (8 items) */}
        <div className="max-w-3xl mx-auto border-t border-white/15">
          {faqItems.map((item, idx) => {
            const isOpen = openId === item.id;
            const panelId = `${item.id}-panel`;
            const buttonId = `${item.id}-button`;

            return (
              <div
                key={item.id}
                className="border-b border-white/15 transition-colors"
              >
                <h3>
                  <button
                    id={buttonId}
                    type="button"
                    onClick={() => toggleItem(item.id)}
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    className="flex w-full items-center justify-between gap-3 sm:gap-4 py-4 sm:py-5 md:py-6 text-left cursor-pointer group focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B6FF00]"
                  >
                    <span className="flex items-baseline gap-2.5 sm:gap-4">
                      <span className="font-mono text-[11px] sm:text-xs font-bold text-[#B6FF00] tabular-nums">
                        {String(idx + 1).padStart(2, "0")}
                      </span>
                      <span
                        className={`font-display text-sm sm:text-base md:text-xl font-bold transition-colors duration-150 ${
                          isOpen
                            ? "text-[#B6FF00]"
                            : "text-white group-hover:text-[#B6FF00]"
                        }`}
                      >
                        {item.question}
                      </span>
                    </span>

                    <span
                      aria-hidden="true"
                      className={`flex h-6 w-6 sm:h-7 sm:w-7 md:h-8 md:w-8 shrink-0 items-center justify-center border transition-colors duration-150 ${
                        isOpen
                          ? "border-[#B6FF00] bg-[#B6FF00] text-black shadow-[0_0_14px_rgba(182,255,0,0.45)]"
                          : "border-white/20 bg-[#060806]/80 text-white shadow-[inset_0_1px_0_0_rgba(240,255,250,0.14)] group-hover:border-[#B6FF00] group-hover:text-[#B6FF00]"
                      }`}
                    >
                      {isOpen ? (
                        <Minus className="h-3 w-3 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4" />
                      ) : (
                        <Plus className="h-3 w-3 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4" />
                      )}
                    </span>
                  </button>
                </h3>

                {isOpen && (
                  <div
                    id={panelId}
                    role="region"
                    aria-labelledby={buttonId}
                    className="pb-4 sm:pb-5 md:pb-6 pl-6 sm:pl-8 md:pl-9 pr-2 sm:pr-4"
                  >
                    <p className="text-[13px] sm:text-base md:text-lg leading-relaxed text-neutral-300">
                      {item.answer}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
