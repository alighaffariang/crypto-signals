import React, { useState } from "react";
import { marqueeStrips, MarqueeStripConfig } from "../data/marqueeData";

interface MarqueeSlotProps {
  src: string;
  stripLabel: string;
  slotIndex: number;
}

const MarqueeSlot: React.FC<MarqueeSlotProps> = ({
  src,
  stripLabel,
  slotIndex,
}) => {
  const [hasError, setHasError] = useState(false);
  const showImage = src.trim().length > 0 && !hasError;

  const formattedNumber = String(slotIndex + 1).padStart(2, "0");

  return (
    <div className="relative aspect-video h-[144px] sm:h-[180px] md:h-[212px] lg:h-[246px] xl:h-[268px] shrink-0 overflow-hidden border border-white/[0.14] bg-[#050605] transition-colors duration-200 hover:border-[#B6FF00]/55 select-none group">
      {showImage ? (
        <img
          src={src}
          alt={`VELINO STUDIO Video Editing Preview ${stripLabel} Slot ${formattedNumber}`}
          loading="eager"
          decoding="async"
          width={480}
          height={270}
          onError={() => setHasError(true)}
          className="block h-full w-full object-cover object-center opacity-100 filter-none transition-transform duration-300 group-hover:scale-[1.02]"
        />
      ) : (
        <div className="flex h-full w-full flex-col justify-between p-2.5 sm:p-3.5 slot-grid-pattern">
          {/* Top subtle technical frame markers */}
          <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-white/30 tabular-nums">
            <span>{stripLabel}</span>
            <span className="text-[#B6FF00]/45">#{formattedNumber}</span>
          </div>

          {/* Center minimal crosshair mark */}
          <div className="flex items-center justify-center">
            <div className="h-2.5 w-2.5 border-t border-l border-white/20" />
            <span className="px-2 font-mono text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-white/25">
              16:9 SLOT
            </span>
            <div className="h-2.5 w-2.5 border-b border-r border-[#B6FF00]/25" />
          </div>

          {/* Bottom subtle indicator */}
          <div className="flex items-center justify-between text-[9px] font-mono tracking-widest text-white/25 tabular-nums">
            <span>1280×720</span>
            <span className="h-1 w-1 bg-[#B6FF00]/65 shadow-[0_0_6px_#B6FF00]" />
          </div>
        </div>
      )}
    </div>
  );
};

const MarqueeRow: React.FC<{ strip: MarqueeStripConfig }> = ({ strip }) => {
  // Duplicate items twice inside a single flex track so translate3d(-50%, 0, 0) loops seamlessly without any jump
  return (
    <div className="relative w-full overflow-hidden">
      <div className={strip.speedClass}>
        {/* First half (50% of track width) */}
        <div className="flex shrink-0 items-center gap-2 sm:gap-3 pr-2 sm:pr-3">
          {strip.items.map((src, idx) => (
            <MarqueeSlot
              key={`${strip.id}-a-${idx}`}
              src={src}
              stripLabel={strip.label}
              slotIndex={idx}
            />
          ))}
        </div>
        {/* Second identical half (50% of track width) for seamless infinite loop */}
        <div
          className="flex shrink-0 items-center gap-2 sm:gap-3 pr-2 sm:pr-3"
          aria-hidden="true"
        >
          {strip.items.map((src, idx) => (
            <MarqueeSlot
              key={`${strip.id}-b-${idx}`}
              src={src}
              stripLabel={strip.label}
              slotIndex={idx}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export const MarqueeGallery: React.FC = () => {
  return (
    <section
      id="top"
      aria-label="Featured Portfolio Reel"
      className="velino-section-divider relative w-full overflow-hidden bg-[#050605] pt-0 pb-0 m-0"
    >
      {/* 4 Stacked Horizontal Continuously Scrolling Strips — 100% Sharp & Unobstructed */}
      <div className="relative z-0 flex flex-col gap-1.5 sm:gap-2 opacity-100">
        {marqueeStrips.map((strip) => (
          <MarqueeRow key={strip.id} strip={strip} />
        ))}
      </div>

      {/* Strong Centered Text Overlay over the Four Marquee Strips */}
      <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-3 sm:px-6 text-center">
        <div className="inline-flex flex-col items-center justify-center px-6 py-6 sm:px-14 sm:py-9 md:px-18 md:py-12 bg-[radial-gradient(closest-side,rgba(0,0,0,0.68)_0%,rgba(0,0,0,0.48)_40%,rgba(0,0,0,0.20)_72%,transparent_100%)]">
          <p className="font-display text-xl sm:text-3xl md:text-5xl lg:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-tight text-center [text-shadow:0_0_16px_rgba(255,255,255,0.28),0_0_36px_rgba(255,255,255,0.14),0_2px_18px_rgba(0,0,0,0.98),0_4px_36px_rgba(0,0,0,0.95)] max-w-4xl">
            Immaculate Professional Cleaning Services LLC
          </p>
        </div>
      </div>
    </section>
  );
};
