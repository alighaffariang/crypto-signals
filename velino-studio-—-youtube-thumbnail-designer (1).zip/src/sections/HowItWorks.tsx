import React from "react";
import { howItWorksSteps } from "../data/siteConfig";

export const HowItWorks: React.FC = () => {
  return (
    <section
      aria-labelledby="how-it-works-heading"
      className="velino-section-divider relative w-full bg-transparent py-12 sm:py-20 md:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <span className="font-mono text-xs sm:text-sm font-bold uppercase tracking-widest text-[#B6FF00]">
            OUR PROCESS
          </span>
          <h2
            id="how-it-works-heading"
            className="mt-2 font-display text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-[-0.03em] text-white leading-tight"
          >
            FROM RAW FOOTAGE TO{" "}
            <span className="velino-luminous-title text-[#B6FF00]">
              READY-TO-PUBLISH.
            </span>
          </h2>
        </div>

        {/* 3 Steps Cards */}
        <div className="mt-8 sm:mt-12 md:mt-18 grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6 lg:gap-8 items-stretch">
          {howItWorksSteps.map((step) => (
            <div
              key={step.number}
              className="velino-glass-card relative flex flex-col items-center text-center p-6 sm:p-8 md:p-10 border border-white/15 transition-all duration-150 hover:border-[#B6FF00]/60"
            >
              <span className="velino-luminous-title font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tighter text-[#B6FF00] leading-none tabular-nums">
                {step.number}
              </span>

              <h3 className="mt-4 sm:mt-6 font-display text-lg sm:text-xl md:text-2xl font-black uppercase tracking-tight text-white">
                {step.title}
              </h3>

              <p className="mt-2 sm:mt-3 max-w-xs text-xs sm:text-sm md:text-base leading-relaxed text-neutral-300">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
