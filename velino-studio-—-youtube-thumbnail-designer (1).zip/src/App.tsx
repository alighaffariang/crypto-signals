import React, { useCallback } from "react";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { Hero } from "./sections/Hero";
import { Stats } from "./sections/Stats";
import { AttentionStatement } from "./sections/AttentionStatement";
import { Testimonials } from "./sections/Testimonials";
import { WhyVelino } from "./sections/WhyVelino";
import { HowItWorks } from "./sections/HowItWorks";
import { Pricing } from "./sections/Pricing";
import { FAQ } from "./sections/FAQ";
import { FinalCta } from "./sections/FinalCta";

export function App() {
  const handleNavigate = useCallback((sectionId: string) => {
    if (sectionId === "top") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, []);

  return (
    <div className="velino-stage relative flex min-h-screen w-full flex-col text-white selection:bg-[#B6FF00] selection:text-black overflow-x-hidden">
      {/* Global Ambient Lighting Accents */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      >
        <div className="absolute -top-32 -right-28 h-[540px] w-[720px] sm:h-[740px] sm:w-[1080px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(182,255,0,0.2)_0%,rgba(182,255,0,0.06)_42%,transparent_74%)] blur-3xl" />
        <div className="absolute -top-16 right-8 h-[260px] w-[420px] sm:h-[360px] sm:w-[620px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(240,255,250,0.12)_0%,rgba(200,240,255,0.03)_48%,transparent_75%)] blur-2xl" />
        <div className="absolute top-[22%] right-[15%] h-[340px] w-[520px] sm:h-[460px] sm:w-[760px] -rotate-12 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(147,51,234,0.065)_0%,rgba(124,58,237,0.025)_48%,transparent_76%)] blur-3xl" />
        <div className="absolute top-[42%] -left-32 h-[420px] w-[520px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(224,242,254,0.05)_0%,transparent_72%)] blur-3xl" />
      </div>

      {/* Sticky Studio Navigation */}
      <Navbar onNavigate={handleNavigate} />

      {/* Main Content Flow */}
      <main className="relative z-10 flex-1">
        {/* 1. Hero Section (Centered headline, badge, and CTAs) */}
        <Hero onNavigate={handleNavigate} />

        {/* 2. Agency Track Record (5,000 EDITED PROJECTS | +300 CLIENTS | 989M VIEWS) */}
        <Stats />

        {/* 3. Introduction & Value Proposition (Centered statement) */}
        <AttentionStatement />

        {/* 4. 3-Row Infinite Testimonial Marquee (With country flags) */}
        <Testimonials />

        {/* 5. Why Work With Velino (Centered heading & 4 cards) */}
        <WhyVelino />

        {/* 6. How It Works (3 Steps) */}
        <HowItWorks />

        {/* 7. Transparent Pricing (Short-Form $50 & Long-Form Interactive Duration Selector) */}
        <Pricing />

        {/* 8. FAQ Section (Centered header & accordion) */}
        <FAQ />

        {/* 9. Final Call to Action */}
        <FinalCta onNavigate={handleNavigate} />
      </main>

      {/* Studio Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default App;
