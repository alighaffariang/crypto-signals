import React, { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { siteConfig, createGeneralInquiryMailto } from "../data/siteConfig";

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 32);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [mobileMenuOpen]);

  const handleLinkClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    sectionId: string
  ) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    onNavigate(sectionId);
  };

  const handleCtaClick = () => {
    setMobileMenuOpen(false);
    window.location.href = createGeneralInquiryMailto("Navbar CTA");
  };

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-colors duration-150 ${
        isScrolled
          ? "bg-[#050705]/92 backdrop-blur-xl border-b border-white/12 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.9),inset_0_-1px_0_0_rgba(182,255,0,0.18)] py-2 sm:py-2.5 md:py-3"
          : "bg-[#050705]/70 backdrop-blur-md border-b border-white/[0.09] shadow-[inset_0_-1px_0_0_rgba(224,242,254,0.1)] py-2.5 sm:py-3.5 md:py-5"
      }`}
    >
      <div className="mx-auto flex max-w-[1280px] items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Identity */}
        <a
          href="#top"
          onClick={(e) => handleLinkClick(e, "top")}
          className="font-display text-sm sm:text-lg md:text-xl font-extrabold uppercase tracking-tight text-white hover:text-[#B6FF00] transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#B6FF00]"
        >
          {siteConfig.brand}
        </a>

        {/* Desktop Navigation */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-7 lg:gap-8"
        >
          <a
            href="#pricing"
            onClick={(e) => handleLinkClick(e, "pricing")}
            className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300 hover:text-[#B6FF00] underline-offset-8 hover:underline transition-colors duration-150 whitespace-nowrap"
          >
            PRICING
          </a>
          <a
            href="#testimonials"
            onClick={(e) => handleLinkClick(e, "testimonials")}
            className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300 hover:text-[#B6FF00] underline-offset-8 hover:underline transition-colors duration-150 whitespace-nowrap"
          >
            REVIEWS
          </a>
          <a
            href="#faq"
            onClick={(e) => handleLinkClick(e, "faq")}
            className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300 hover:text-[#B6FF00] underline-offset-8 hover:underline transition-colors duration-150 whitespace-nowrap"
          >
            FAQ
          </a>
          <a
            href={`mailto:${siteConfig.email}`}
            className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300 hover:text-[#B6FF00] underline-offset-8 hover:underline transition-colors duration-150 whitespace-nowrap"
          >
            CONTACT
          </a>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <button
            type="button"
            onClick={handleCtaClick}
            className="velino-neon-btn hidden sm:inline-flex items-center justify-center bg-[#B6FF00] px-3.5 py-2 md:px-4 md:py-2.5 text-[11px] md:text-xs font-bold uppercase tracking-wider text-black transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#c8ff3d] active:translate-y-0 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B6FF00]"
          >
            GET YOUR VIDEO EDITED
          </button>

          {/* Mobile Hamburger Trigger */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={
              mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"
            }
            className="inline-flex md:hidden h-8 w-8 sm:h-9 sm:w-9 items-center justify-center border border-white/15 bg-[#070907] text-white shadow-[inset_0_1px_0_0_rgba(255,255,255,0.14)] hover:border-[#B6FF00] hover:text-[#B6FF00] transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#B6FF00]"
          >
            {mobileMenuOpen ? (
              <X className="h-4 w-4" />
            ) : (
              <Menu className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#060806]/98 backdrop-blur-xl px-4 pt-2.5 pb-4">
          <nav
            aria-label="Mobile Navigation"
            className="flex flex-col space-y-0.5"
          >
            <a
              href="#pricing"
              onClick={(e) => handleLinkClick(e, "pricing")}
              className="py-2.5 text-xs font-bold uppercase tracking-[0.14em] text-white hover:text-[#B6FF00] border-b border-white/[0.06] transition-colors"
            >
              PRICING
            </a>
            <a
              href="#testimonials"
              onClick={(e) => handleLinkClick(e, "testimonials")}
              className="py-2.5 text-xs font-bold uppercase tracking-[0.14em] text-white hover:text-[#B6FF00] border-b border-white/[0.06] transition-colors"
            >
              REVIEWS
            </a>
            <a
              href="#faq"
              onClick={(e) => handleLinkClick(e, "faq")}
              className="py-2.5 text-xs font-bold uppercase tracking-[0.14em] text-white hover:text-[#B6FF00] border-b border-white/[0.06] transition-colors"
            >
              FAQ
            </a>
            <a
              href={`mailto:${siteConfig.email}`}
              className="py-2.5 text-xs font-bold uppercase tracking-[0.14em] text-white hover:text-[#B6FF00] border-b border-white/[0.06] transition-colors"
            >
              CONTACT
            </a>
            <div className="pt-3">
              <button
                type="button"
                onClick={handleCtaClick}
                className="velino-neon-btn flex w-full items-center justify-center bg-[#B6FF00] px-4 py-2.5 text-[11px] font-extrabold uppercase tracking-wider text-black transition-colors hover:bg-[#c8ff3d] whitespace-nowrap cursor-pointer"
              >
                GET YOUR VIDEO EDITED
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
