import React from "react";
import { siteConfig } from "../data/siteConfig";

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    sectionId: string
  ) => {
    e.preventDefault();
    onNavigate(sectionId);
  };

  return (
    <footer className="relative z-10 mt-auto w-full bg-[#040504]/90 pt-8 pb-7 sm:pt-12 sm:pb-9 md:pt-16 md:pb-12 text-white border-t border-white/10">
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 sm:gap-8 md:gap-10">
          {/* Brand Column */}
          <div>
            <p className="velino-luminous-subtitle font-display text-lg sm:text-2xl md:text-3xl font-black uppercase tracking-tight text-[#B6FF00]">
              {siteConfig.brand}
            </p>
            <p className="mt-1 sm:mt-1.5 md:mt-2 font-display text-xs sm:text-sm md:text-base font-bold uppercase tracking-wider text-white">
              {siteConfig.tagline}
            </p>
            <p className="mt-1 sm:mt-1.5 text-xs sm:text-sm text-neutral-400 max-w-md">
              We turn raw footage into high-retention video content for YouTube, Shorts, and Reels.
            </p>
            <p className="mt-2 text-xs font-mono text-neutral-400">
              Agency Contact:{" "}
              <a
                href={`mailto:${siteConfig.email}`}
                className="text-[#B6FF00] hover:underline"
              >
                {siteConfig.email}
              </a>
            </p>
          </div>

          {/* Navigation & Socials */}
          <nav
            aria-label="Footer Navigation"
            className="flex flex-wrap items-center gap-4 sm:gap-6 md:gap-8"
          >
            <a
              href="#pricing"
              onClick={(e) => handleNavClick(e, "pricing")}
              className="text-xs md:text-sm font-semibold text-neutral-300 hover:text-[#B6FF00] transition-colors whitespace-nowrap"
            >
              Pricing
            </a>
            <a
              href="#testimonials"
              onClick={(e) => handleNavClick(e, "testimonials")}
              className="text-xs md:text-sm font-semibold text-neutral-300 hover:text-[#B6FF00] transition-colors whitespace-nowrap"
            >
              Reviews
            </a>
            <a
              href="#faq"
              onClick={(e) => handleNavClick(e, "faq")}
              className="text-xs md:text-sm font-semibold text-neutral-300 hover:text-[#B6FF00] transition-colors whitespace-nowrap"
            >
              FAQ
            </a>
            <a
              href={`mailto:${siteConfig.email}`}
              className="text-xs md:text-sm font-semibold text-neutral-300 hover:text-[#B6FF00] transition-colors whitespace-nowrap"
            >
              Contact
            </a>
          </nav>
        </div>

        <div className="mt-8 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-neutral-500">
          <p>© {new Date().getFullYear()} VELINO STUDIO. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
