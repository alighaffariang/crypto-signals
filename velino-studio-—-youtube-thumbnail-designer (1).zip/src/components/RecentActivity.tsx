import React, { useState, useEffect, useRef } from "react";
import { X } from "lucide-react";
import {
  initialRecentOrders,
  RecentOrderEvent,
  countryCodeToFlag,
  formatOrderMessage,
} from "../data/ordersData";

const CYCLE_INTERVAL_MS = 30000;
const VISIBLE_DURATION_MS = 6500;

export const RecentActivity: React.FC = () => {
  const [orders] = useState<RecentOrderEvent[]>(initialRecentOrders);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissedPermanently, setIsDismissedPermanently] = useState(false);

  const cycleTimerRef = useRef<number | null>(null);
  const hideTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (orders.length === 0 || isDismissedPermanently) {
      setIsVisible(false);
      return;
    }

    const scheduleCycle = (nextIdx: number) => {
      cycleTimerRef.current = window.setTimeout(() => {
        setCurrentIndex(nextIdx);
        setIsVisible(true);

        hideTimerRef.current = window.setTimeout(() => {
          setIsVisible(false);
          const followingIdx = (nextIdx + 1) % orders.length;
          scheduleCycle(followingIdx);
        }, VISIBLE_DURATION_MS);
      }, CYCLE_INTERVAL_MS);
    };

    scheduleCycle(currentIndex);

    return () => {
      if (cycleTimerRef.current) window.clearTimeout(cycleTimerRef.current);
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
  }, [orders, isDismissedPermanently]);

  if (orders.length === 0 || isDismissedPermanently) {
    return null;
  }

  const currentOrder = orders[currentIndex];
  if (!currentOrder) return null;

  const flag = countryCodeToFlag(currentOrder.countryCode);
  const message = formatOrderMessage(currentOrder);

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed top-2.5 sm:top-4 left-1/2 z-50 w-[calc(100vw-1.5rem)] sm:w-[calc(100vw-2rem)] max-w-xs sm:max-w-md -translate-x-1/2 pointer-events-none transition-transform duration-300 ease-out ${
        isVisible
          ? "translate-y-0 opacity-100"
          : "-translate-y-[150%] opacity-0"
      }`}
    >
      <div className="velino-featured-surface pointer-events-auto flex items-center justify-between gap-2 sm:gap-3 border border-[#B6FF00]/65 px-3 py-2 sm:px-4 sm:py-3 backdrop-blur-xl">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {flag && (
            <span
              className="text-base sm:text-xl leading-none select-none shrink-0"
              aria-hidden="true"
            >
              {flag}
            </span>
          )}
          <div className="min-w-0">
            <p className="truncate text-[11px] sm:text-xs font-bold text-white">
              {currentOrder.firstName} from {currentOrder.country}
            </p>
            <p className="truncate text-[11px] sm:text-xs font-medium text-[#B6FF00]">
              {message}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setIsVisible(false);
            if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
            if (cycleTimerRef.current)
              window.clearTimeout(cycleTimerRef.current);
            const nextIdx = (currentIndex + 1) % orders.length;
            cycleTimerRef.current = window.setTimeout(() => {
              setCurrentIndex(nextIdx);
              setIsVisible(true);
            }, CYCLE_INTERVAL_MS);
          }}
          onDoubleClick={() => {
            setIsVisible(false);
            setIsDismissedPermanently(true);
          }}
          aria-label="Close recent order notification"
          className="flex h-6 w-6 sm:h-7 sm:w-7 shrink-0 items-center justify-center border border-white/10 text-neutral-400 hover:border-[#B6FF00] hover:text-[#B6FF00] transition-colors"
        >
          <X className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
        </button>
      </div>
    </div>
  );
};
