/**
 * REAL ORDERS DATA SOURCE FOR RECENT ACTIVITY NOTIFICATIONS
 *
 * IMPORTANT:
 * Only populate `realOrders` with verified, real client purchases.
 * Never add fabricated names, countries, or purchases.
 * When `realOrders` is empty ([]), the top notification system remains
 * completely dormant and displays nothing to visitors.
 *
 * You can also configure `ORDER_API_ENDPOINT` to fetch verified recent orders
 * from your backend or payment webhook endpoint.
 */

export interface RealOrder {
  id: string;
  firstName: string;
  country: string;
  countryCode: string; // ISO 2-letter code e.g. "US", "GB", "CA"
  quantity?: number;
  packageName?: string; // e.g., "a 5-thumbnail package", "a 10-thumbnail package"
  timestamp: string; // ISO timestamp string
}

export const ORDER_API_ENDPOINT: string = "";

export const realOrders: RealOrder[] = [
  // Add verified real orders here when they occur.
  // Example structure (keep commented out unless real):
  // {
  //   id: "ord_01",
  //   firstName: "Alex",
  //   country: "the United States",
  //   countryCode: "US",
  //   quantity: 3,
  //   timestamp: "2026-10-07T12:00:00Z",
  // },
];

/**
 * Converts a 2-letter ISO country code (e.g. "US", "GB", "CA")
 * into its regional indicator flag emoji (🇺🇸, 🇬🇧, 🇨🇦).
 */
export function countryCodeToFlag(countryCode: string): string {
  const code = countryCode.trim().toUpperCase();
  if (code.length !== 2) return "";
  const codePoints = [...code].map((char) => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
}

/**
 * Formats the order action message according to the order record fields.
 */
export function formatOrderAction(order: RealOrder): string {
  if (order.packageName && order.packageName.trim().length > 0) {
    return `just booked ${order.packageName.trim()}`;
  }
  if (typeof order.quantity === "number" && order.quantity > 0) {
    return `just ordered ${order.quantity} ${
      order.quantity === 1 ? "video" : "videos"
    }`;
  }
  return "just ordered a video edit";
}

export type RecentOrderEvent = RealOrder;
export const initialRecentOrders: RecentOrderEvent[] = realOrders;
export const formatOrderMessage = formatOrderAction;
