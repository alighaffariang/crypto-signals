/**
 * TESTIMONIALS DATA CONFIGURATION
 *
 * NOTE: The reviews below are placeholder preview entries designed to showcase
 * the three-row infinite marquee layout. Replace these entries with verified
 * client testimonials and feedback prior to production publishing.
 *
 * Structure for each entry:
 * - review: The testimonial body text
 * - name: Reviewer full name
 * - country: Reviewer country (in English)
 * - flag: Country national flag emoji
 */

export interface TestimonialEntry {
  id: string;
  review: string;
  name: string;
  country: string;
  flag: string;
  isPlaceholder?: boolean;
}

export const testimonialsHeading = {
  sectionTitle: "CREATORS ARE TALKING.",
  supportingText: "REAL EXPERIENCES. CREATOR-FOCUSED EDITING.",
};

// Row 1 Testimonials (Moves Left to Right)
export const row1Testimonials: TestimonialEntry[] = [
  {
    id: "r1-1",
    name: "Jordan Miller",
    country: "United States",
    flag: "🇺🇸",
    review:
      "Pacing and retention on our YouTube videos improved noticeably within the first two weeks. The visual hooks and cuts keep viewers locked in.",
    isPlaceholder: true,
  },
  {
    id: "r1-2",
    name: "Emily Carter",
    country: "Canada",
    flag: "🇨🇦",
    review:
      "Our raw footage was a chaotic multi-angle recording, but the final cut was clean, punchy, and delivered right on time.",
    isPlaceholder: true,
  },
  {
    id: "r1-3",
    name: "Oliver Bennett",
    country: "United Kingdom",
    flag: "🇬🇧",
    review:
      "Consistent turnaround and stellar sound design. We publish weekly without having to worry about editing bottlenecks anymore.",
    isPlaceholder: true,
  },
  {
    id: "r1-4",
    name: "Sophia Wilson",
    country: "Australia",
    flag: "🇦🇺",
    review:
      "The dynamic zoom cuts and subtitle styling gave our educational breakdowns a much higher production value.",
    isPlaceholder: true,
  },
  {
    id: "r1-5",
    name: "Daniel Weber",
    country: "Germany",
    flag: "🇩🇪",
    review:
      "Communication was sharp from day one. They took our script notes and delivered an edit that exceeded expectations.",
    isPlaceholder: true,
  },
  {
    id: "r1-6",
    name: "Lucas Martin",
    country: "France",
    flag: "🇫🇷",
    review:
      "Fast delivery, zero fluff, and great narrative instincts. The best editing agency partnership we've had so far.",
    isPlaceholder: true,
  },
];

// Row 2 Testimonials (Moves Right to Left)
export const row2Testimonials: TestimonialEntry[] = [
  {
    id: "r2-1",
    name: "Marcus Chen",
    country: "Singapore",
    flag: "🇸🇬",
    review:
      "Our viewer watch time increased noticeably after switching our long-form video editing to VELINO. The retention pacing speaks for itself.",
    isPlaceholder: true,
  },
  {
    id: "r2-2",
    name: "Hannah Brooks",
    country: "United States",
    flag: "🇺🇸",
    review:
      "They nail the micro-transitions and audio leveling on every single cut. Our podcast highlights look broadcast-grade.",
    isPlaceholder: true,
  },
  {
    id: "r2-3",
    name: "Liam O'Connor",
    country: "Ireland",
    flag: "🇮🇪",
    review:
      "Reliable, transparent pricing and no guesswork. Having a dedicated team handle the heavy editing lets me focus purely on creating.",
    isPlaceholder: true,
  },
  {
    id: "r2-4",
    name: "Chloe Dubois",
    country: "Canada",
    flag: "🇨🇦",
    review:
      "Every video feels custom-crafted for our specific audience instead of following a generic template.",
    isPlaceholder: true,
  },
  {
    id: "r2-5",
    name: "Stefan Lindqvist",
    country: "Sweden",
    flag: "🇸🇪",
    review:
      "From sound effects to color grading, the attention to detail is noticeable on every upload.",
    isPlaceholder: true,
  },
  {
    id: "r2-6",
    name: "Alex Rivera",
    country: "United States",
    flag: "🇺🇸",
    review:
      "Turnaround is fast and revisions are handled seamlessly. Couldn't ask for a better creative partner.",
    isPlaceholder: true,
  },
];

// Row 3 Testimonials (Moves Left to Right)
export const row3Testimonials: TestimonialEntry[] = [
  {
    id: "r3-1",
    name: "Noah Tanaka",
    country: "Japan",
    flag: "🇯🇵",
    review:
      "The short-form cuts helped our channel gain massive traction across YouTube Shorts.",
    isPlaceholder: true,
  },
  {
    id: "r3-2",
    name: "Isabella Rossi",
    country: "Italy",
    flag: "🇮🇹",
    review:
      "Clean storytelling with crisp visual hierarchy. They make complex tutorial topics effortless to watch.",
    isPlaceholder: true,
  },
  {
    id: "r3-3",
    name: "David Miller",
    country: "United Kingdom",
    flag: "🇬🇧",
    review:
      "Saved our production team over 30 hours every month. The quality and pacing are consistently top-notch.",
    isPlaceholder: true,
  },
  {
    id: "r3-4",
    name: "Maya Patel",
    country: "United States",
    flag: "🇺🇸",
    review:
      "Their editing style brought so much energy and curiosity into our talking-head segments. Absolutely recommend.",
    isPlaceholder: true,
  },
  {
    id: "r3-5",
    name: "Felix Novak",
    country: "Germany",
    flag: "🇩🇪",
    review:
      "Great communication, clear workflow, and dependable delivery schedules every single week.",
    isPlaceholder: true,
  },
  {
    id: "r3-6",
    name: "Sarah Jenkins",
    country: "Australia",
    flag: "🇦🇺",
    review:
      "Our audience constantly comments on how clean the edits look. An indispensable partner for serious content creators.",
    isPlaceholder: true,
  },
];
