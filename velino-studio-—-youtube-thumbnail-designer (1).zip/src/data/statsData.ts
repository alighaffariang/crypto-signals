/**
 * AGENCY STATISTICS DATA
 *
 * Central configuration for the 3 statistics displayed in the Stats section.
 * These figures represent the verified metrics supplied by the agency owner.
 * Easily edit target values, formatting, prefixes, and labels here.
 */

export interface AgencyStat {
  id: string;
  targetValue: number;
  prefix: string;
  suffix: string;
  formatCommas: boolean;
  label: string;
  finalDisplay: string;
}

export const agencyStatistics: AgencyStat[] = [
  {
    id: "edited-projects",
    targetValue: 5000,
    prefix: "+",
    suffix: "",
    formatCommas: true,
    label: "PROJECTS",
    finalDisplay: "+5,000",
  },
  {
    id: "clients",
    targetValue: 300,
    prefix: "+",
    suffix: "",
    formatCommas: false,
    label: "CLIENTS",
    finalDisplay: "+300",
  },
  {
    id: "views",
    targetValue: 989,
    prefix: "",
    suffix: "M",
    formatCommas: false,
    label: "VIEWS",
    finalDisplay: "989M",
  },
];
