import img01 from "../../Photo/0054f8cbb989c6e412c42c3923f310f7.webp";
import img02 from "../../Photo/0356725e53f8d6240a14ad6dac91eba0.webp";
import img03 from "../../Photo/086920c46562a90748bcb907a2761827.webp";
import img04 from "../../Photo/1c60d3c368126fbc2b65c981fc163f33.webp";
import img05 from "../../Photo/388b68a1d15c1b04a67e012dd9851a46.webp";
import img06 from "../../Photo/401e633d6a094e40fe889e7dd8c01427.webp";
import img07 from "../../Photo/4df3dbc7950bb8463f355f135e7b9f7c.webp";

import img08 from "../../Photo/60878cca95ccf9dd763fa8eae51dc884.webp";
import img09 from "../../Photo/6425d49818b855c35385a7a8cc8c75b5.webp";
import img10 from "../../Photo/69ea9ca8dc006815a693c7f2ee9ad012.webp";
import img11 from "../../Photo/6a8f60dd68c15b0d852a43fc6e500ae4.webp";
import img12 from "../../Photo/6b79af65534dbb0542a59c67e6fd49b6 (1).webp";
import img13 from "../../Photo/7180c9ff977134a149feab1d3461a372.webp";
import img14 from "../../Photo/727ec12b9d551cacd14c87e3eefe8025.webp";

import img15 from "../../Photo/767e253b6627653cb0b54d2049c28e46.webp";
import img16 from "../../Photo/8169ca6ebe6da0d79f1ea80e26715e6b.webp";
import img17 from "../../Photo/8ca9d89a1708c3cb83c6aa2e9148dc98.webp";
import img18 from "../../Photo/9ddb1dfd094db67f5fa170735fc69872.webp";
import img19 from "../../Photo/9e5422d1194ab4b59637e28d20d08bb8.webp";
import img20 from "../../Photo/aa89919325eed43e0ae88cc5ec75c963.webp";
import img21 from "../../Photo/ba0d9280d12dce1422f9a7f63fdd6f7b.webp";

import img22 from "../../Photo/c134d8b47da3e2704a981a90a3dc651e.webp";
import img23 from "../../Photo/c5932cb9340520a8592b0b402ad7ea97.webp";
import img24 from "../../Photo/cbf605fe672a4ed1e2c6b529197ad2db.webp";
import img25 from "../../Photo/d700c6c539bd1bca7c827426d3731ce4.webp";
import img26 from "../../Photo/e58f6289b08c3ff7117769e6a1072a82.webp";
import img27 from "../../Photo/f13ebaf3e49c39b8eae2f73a9bfabb16.webp";
import img28 from "../../Photo/f2d398f91ebc12af47b82ee9c04da19d.webp";

export interface MarqueeStripConfig {
  id: string;
  label: string;
  direction: "rtl" | "ltr";
  speedClass: string;
  items: string[];
}

export const marqueeStrips: MarqueeStripConfig[] = [
  {
    id: "strip-01",
    label: "ROW 01",
    direction: "rtl",
    speedClass: "animate-marquee-rtl",
    items: [img01, img02, img03, img04, img05, img06, img07],
  },
  {
    id: "strip-02",
    label: "ROW 02",
    direction: "ltr",
    speedClass: "animate-marquee-ltr",
    items: [img08, img09, img10, img11, img12, img13, img14],
  },
  {
    id: "strip-03",
    label: "ROW 03",
    direction: "rtl",
    speedClass: "animate-marquee-rtl-slow",
    items: [img15, img16, img17, img18, img19, img20, img21],
  },
  {
    id: "strip-04",
    label: "ROW 04",
    direction: "ltr",
    speedClass: "animate-marquee-ltr-slow",
    items: [img22, img23, img24, img25, img26, img27, img28],
  },
];
