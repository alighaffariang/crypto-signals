export interface ServiceItem {
  id: string;
  badge: string;
  title: string;
  description: string;
  features: string[];
  pricingLabel: string;
  ctaText: string;
  targetPackageId: string;
}

export interface LongFormPricingPackage {
  id: string;
  name: string;
  duration: string;
  price: string;
  description: string;
  ctaText: string;
  popular?: boolean;
}

export interface ShortFormPricingOffer {
  id: string;
  name: string;
  price: string;
  includes: string[];
  ctaText: string;
  note: string;
}

export interface WhyVelinoItem {
  id: string;
  index: string;
  title: string;
  description: string;
}

export interface ProcessStep {
  number: string;
  title: string;
  description: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface StatItem {
  id: string;
  title: string;
  description: string;
  tag: string;
}

export const siteConfig = {
  brand: "VELINO STUDIO",
  tagline: "Professional Video Editing for Content Creators.",
  email: "officialvelino@gmail.com",
};

export const heroContent = {
  brand: "VELINO STUDIO",
  headlineLine1: "YOUR CONTENT.",
  headlineLine2: "OUR EDITING.",
  headlineLine3: "YOUR NEXT LEVEL.",
  supportingHeadline: "VIDEO EDITING THAT KEEPS PEOPLE WATCHING.",
  description:
    "We turn raw footage into engaging, professionally edited videos designed to capture attention, keep viewers watching, and help creators publish consistently.",
  primaryCta: "LET'S EDIT YOUR VIDEO",
  secondaryCta: "EXPLORE OUR WORK",
};

export const statsItems: StatItem[] = [
  {
    id: "short-form-benefit",
    title: "SHORT-FORM CONTENT",
    description: "Built for attention.",
    tag: "9:16 VERTICAL",
  },
  {
    id: "long-form-benefit",
    title: "LONG-FORM VIDEOS",
    description: "Edited for engagement.",
    tag: "16:9 CINEMATIC",
  },
  {
    id: "creator-focused-benefit",
    title: "CREATOR-FOCUSED",
    description: "Built around your vision.",
    tag: "AGENCY QUALITY",
  },
];

export const valueProposition = {
  headline: "YOUR CONTENT DESERVES MORE THAN BASIC EDITING.",
  supportingText:
    "Great content can lose attention when the editing fails to deliver. We help creators turn raw footage into polished videos with better pacing, engaging visuals, and a professional finish.",
  closingStatementLine1: "YOU CREATE THE CONTENT.",
  closingStatementLine2: "WE MAKE IT WATCHABLE.",
};

export const servicesData: ServiceItem[] = [
  {
    id: "short-form-service",
    badge: "SERVICE 01",
    title: "YOUTUBE SHORTS & SHORT-FORM VIDEO EDITING",
    description:
      "Fast-paced, engaging edits designed for YouTube Shorts and Instagram Reels.",
    features: [
      "Clean cuts and smooth pacing",
      "Engaging subtitles when needed",
      "Sound effects and music",
      "Zooms, transitions, and visual emphasis",
      "Platform-ready export",
    ],
    pricingLabel: "Starting at $50 / VIDEO",
    ctaText: "ORDER SHORT-FORM EDITING",
    targetPackageId: "short-form-50",
  },
  {
    id: "long-form-service",
    badge: "SERVICE 02",
    title: "LONG-FORM VIDEO EDITING",
    description:
      "Professional editing for YouTube videos, creator content, commentary, educational videos, and other long-form formats.",
    features: [
      "Structured cuts and pacing",
      "Audio cleanup and balancing",
      "Music and sound effects",
      "Supporting visuals when required",
      "Text, transitions, and visual enhancements",
      "High-quality final export",
    ],
    pricingLabel: "Starting at $100 / VIDEO",
    ctaText: "CHOOSE YOUR PACKAGE",
    targetPackageId: "long-form-standard",
  },
];

export const longFormPackages: LongFormPricingPackage[] = [
  {
    id: "short-cut",
    name: "SHORT CUT",
    duration: "1–3 MINUTES",
    price: "$100",
    description:
      "Professional editing for short YouTube videos and compact content.",
    ctaText: "SELECT PACKAGE",
  },
  {
    id: "standard-cut",
    name: "STANDARD CUT",
    duration: "3–5 MINUTES",
    price: "$150",
    description:
      "Polished editing with engaging pacing and clean visual presentation.",
    ctaText: "SELECT PACKAGE",
    popular: true,
  },
  {
    id: "extended-cut",
    name: "EXTENDED CUT",
    duration: "5–10 MINUTES",
    price: "$200",
    description:
      "A complete editing package for longer videos that need consistent pacing and a professional finish.",
    ctaText: "SELECT PACKAGE",
  },
  {
    id: "custom-project",
    name: "CUSTOM PROJECT",
    duration: "OVER 10 MINUTES",
    price: "LET'S TALK",
    description:
      "Custom pricing based on project requirements, editing complexity, and scope.",
    ctaText: "GET A CUSTOM QUOTE",
  },
];

export const shortFormOffer: ShortFormPricingOffer = {
  id: "short-form-50",
  name: "SHORT-FORM VIDEO EDITING",
  price: "$50 / VIDEO",
  includes: [
    "Engaging cuts and pacing",
    "Music and sound effects",
    "Subtitles when needed",
    "Professional transitions and visual enhancements",
    "Unlimited revisions until you're completely satisfied",
    "24-hour delivery",
  ],
  ctaText: "GET STARTED",
  note: "Advanced motion graphics or highly customized requirements may require a separate quote.",
};

export const whyVelinoItems: WhyVelinoItem[] = [
  {
    id: "benefit-01",
    index: "01",
    title: "EDITING BUILT AROUND YOUR CONTENT",
    description:
      "Every video is edited according to its purpose, audience, and creative direction.",
  },
  {
    id: "benefit-02",
    index: "02",
    title: "ATTENTION TO DETAIL",
    description:
      "We focus on pacing, audio, visual clarity, and details that make the final video feel polished.",
  },
  {
    id: "benefit-03",
    index: "03",
    title: "A CONSISTENT WORKFLOW",
    description:
      "A clear process helps creators manage recurring content without handling every editing task themselves.",
  },
  {
    id: "benefit-04",
    index: "04",
    title: "YOUR VISION COMES FIRST",
    description:
      "Share your footage, references, and preferences. We work toward an edit that matches your expectations.",
  },
];

export const howItWorksSteps: ProcessStep[] = [
  {
    number: "1",
    title: "SEND YOUR FOOTAGE",
    description:
      "Share your raw footage, project details, references, and preferred editing style.",
  },
  {
    number: "2",
    title: "WE EDIT",
    description:
      "Our team edits your footage according to the selected package and agreed requirements.",
  },
  {
    number: "3",
    title: "REVIEW & RECEIVE",
    description:
      "Review your edited video and request any changes you need. We’ll keep refining the edit until you’re completely satisfied, then deliver your final video.",
  },
];

export const testimonialsSectionContent = {
  heading: "CREATORS COME FIRST.",
  supportingText:
    "We believe great collaboration starts with clear communication and attention to detail.",
  statement:
    "We believe great collaboration starts with clear communication and attention to detail. We are currently onboarding our next cohort of creators. Reach out to collaborate or request client references.",
};

export const faqItems: FaqItem[] = [
  {
    id: "faq-01",
    question: "How much does video editing cost?",
    answer:
      "Short-form video editing is $50 per video. Long-form editing starts at $100 for 1–3 minutes ($150 for 3–5 minutes, $200 for 5–10 minutes). Videos over 10 minutes receive a custom quote.",
  },
  {
    id: "faq-02",
    question: "What do you need from me?",
    answer:
      "We typically need your raw footage, preferred video length, editing references, and any specific instructions for the project.",
  },
  {
    id: "faq-03",
    question: "What is raw footage?",
    answer:
      "Raw footage is the original, unedited video material you provide. We use it to create your final edited video.",
  },
  {
    id: "faq-04",
    question: "How long does editing take?",
    answer:
      "Our standard delivery time is 24 hours. We turnaround your edited video within 24 hours so you can stay consistent with your publishing schedule. For complex or high-volume projects, exact timelines are confirmed in advance.",
  },
  {
    id: "faq-05",
    question: "Can I request a specific editing style?",
    answer:
      "Absolutely. Share reference videos or explain the style you want, and we will use them to guide the editing process.",
  },
  {
    id: "faq-06",
    question: "Do you offer revisions?",
    answer:
      "Yes. We offer unlimited revisions until you are completely satisfied with the final edit. We'll keep refining the video until it matches your exact expectations.",
  },
  {
    id: "faq-07",
    question: "Can you edit videos longer than 10 minutes?",
    answer:
      "Yes. Videos longer than 10 minutes are available through custom pricing. Contact us with your project details and editing requirements to receive a quote.",
  },
  {
    id: "faq-08",
    question: "Can I order multiple videos every month?",
    answer:
      "Yes. Contact us to discuss recurring editing requirements and a workflow tailored to your content schedule.",
  },
];

export const finalCtaContent = {
  headline: "READY TO LEVEL UP YOUR CONTENT?",
  primaryCta: "LET'S EDIT YOUR VIDEO",
};

/**
 * Generates a prefilled email link to officialvelino@gmail.com
 * formatted strictly according to client communication specifications.
 */
export function createInquiryMailto(params: {
  service: "Short-Form Video Editing" | "Long-Form Video Editing" | "General Inquiry";
  duration?: string;
  price?: string;
}): string {
  const subject = "VELINO STUDIO — Video Editing Inquiry";
  let body = "";

  if (params.service === "Short-Form Video Editing") {
    body = [
      "Hello VELINO STUDIO,",
      "",
      "I am interested in placing an order for video editing.",
      "",
      "Selected service: Short-Form Video Editing",
      "Displayed price: $50 / video",
      "",
      "Please let me know the next steps to get started.",
      "",
      "Thank you.",
    ].join("\r\n");
  } else if (params.service === "Long-Form Video Editing") {
    const isCustom =
      params.duration?.toUpperCase().includes("OVER 10") ||
      params.price?.toUpperCase().includes("CUSTOM");

    if (isCustom) {
      body = [
        "Hello VELINO STUDIO,",
        "",
        "I am interested in placing an order for video editing.",
        "",
        "Selected service: Long-Form Video Editing",
        "Selected duration: Over 10 Minutes",
        "Displayed price: Custom Quote",
        "",
        "Please let me know the next steps to receive a quote.",
        "",
        "Thank you.",
      ].join("\r\n");
    } else {
      let formattedPrice = params.price || "$100 / video";
      if (!formattedPrice.toLowerCase().includes("video")) {
        formattedPrice = `${formattedPrice} / video`;
      }

      body = [
        "Hello VELINO STUDIO,",
        "",
        "I am interested in placing an order for video editing.",
        "",
        "Selected service: Long-Form Video Editing",
        `Selected duration: ${params.duration || "1–3 Minutes"}`,
        `Displayed price: ${formattedPrice}`,
        "",
        "Please let me know the next steps to get started.",
        "",
        "Thank you.",
      ].join("\r\n");
    }
  } else {
    body = [
      "Hello VELINO STUDIO,",
      "",
      "I would like to get my video edited and discuss my project.",
      "",
      "Please let me know the next steps to get started.",
      "",
      "Thank you.",
    ].join("\r\n");
  }

  return `mailto:${siteConfig.email}?subject=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(body)}`;
}

export function createGeneralInquiryMailto(context = "general"): string {
  return createInquiryMailto({ service: "General Inquiry" });
}
